# Carry-On Pick-Up Android starter

Native Android starter for the Carry-On Pick-Up courier app, initially for Abhaynagar, Jashore.

## Build an APK with GitHub Actions
1. Upload the contents of this folder to the root of the `carry-on-pick-up` GitHub repository (not the outer folder itself).
2. Commit the files to the `main` branch.
3. Open the repository's **Actions** tab.
4. Select **Build Carry-On Pick-Up APK** and press **Run workflow** if it did not start automatically.
5. When the workflow succeeds, open that workflow run, scroll to **Artifacts**, and download `Carry-On-Pick-Up-debug-apk`.
6. Extract the ZIP and install `app-debug.apk` on your Android phone. Android may ask you to allow installation from that browser/file manager.

## Current demo limitations
- Booking data is stored locally on the same phone only.
- No online admin panel, customer accounts, payment, backend, or live GPS tracking is connected.
- Do not use real customer personal information in this demo. Add secure backend/authentication before launching a real service.
