package com.carryonpickup.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private final int green = Color.rgb(15,118,110);
    private final int dark = Color.rgb(16,42,42);
    private final int muted = Color.rgb(97,117,116);
    private final int bg = Color.rgb(243,248,247);
    private SharedPreferences prefs;
    private EditText sender, phone, pickup, receiver, receiverPhone, delivery, instructions, trackInput;
    private Spinner parcelType, weight;
    private TextView bookingResult, trackingResult;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("carry_on_demo", MODE_PRIVATE);
        buildScreen();
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(16), dp(16), dp(16), dp(28));
        page.setBackgroundColor(bg);
        scroll.addView(page);

        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(18), dp(22), dp(18), dp(22));
        hero.setBackground(round(Color.rgb(6,78,59), 22));
        TextView brand = text("📦  Carry-On Pick-Up", 23, Color.WHITE, true);
        hero.addView(brand);
        TextView location = text("LOCAL COURIER  •  ABHAYNAGAR, JASHORE", 12, Color.rgb(217,245,238), true);
        LinearLayout.LayoutParams lp = params(-1, -2); lp.topMargin = dp(8); hero.addView(location, lp);
        TextView title = text("Your parcel.\nPicked up & delivered.", 28, Color.WHITE, true);
        lp = params(-1, -2); lp.topMargin = dp(22); hero.addView(title, lp);
        TextView intro = text("Book local delivery for clothing, food and online-shop parcels.", 14, Color.rgb(217,245,238), false);
        lp = params(-1, -2); lp.topMargin = dp(8); hero.addView(intro, lp);
        page.addView(hero);

        LinearLayout stats = new LinearLayout(this); stats.setOrientation(LinearLayout.HORIZONTAL);
        addStat(stats, "📍 Local", "Abhaynagar"); addStat(stats, "📦 Easy", "Parcel booking"); addStat(stats, "🚚 Direct", "Pickup & delivery");
        lp = params(-1, -2); lp.topMargin = dp(12); page.addView(stats, lp);

        LinearLayout booking = card(page, "📦  Book a parcel", "Enter sender and receiver details.");
        sender = field(booking, "Sender name *", "Your name");
        phone = field(booking, "Sender phone *", "01XXXXXXXXX");
        pickup = field(booking, "Pickup address in Abhaynagar *", "Village/area, road, landmark", true);
        receiver = field(booking, "Receiver name *", "Receiver name");
        receiverPhone = field(booking, "Receiver phone *", "01XXXXXXXXX");
        delivery = field(booking, "Delivery address *", "Village/area, road, landmark", true);
        parcelType = spinner(booking, "Parcel type *", new String[]{"Choose parcel type", "Clothing", "Food", "Online shop product", "Document", "Other allowed item"});
        weight = spinner(booking, "Approximate weight", new String[]{"Small (under 1 kg)", "Medium (1–3 kg)", "Large (over 3 kg)"});
        instructions = field(booking, "Extra instructions (optional)", "Pickup time or delivery notes", true);
        Button submit = button("Create booking request"); booking.addView(submit, params(-1,-2));
        bookingResult = text("", 14, dark, false); lp = params(-1,-2); lp.topMargin=dp(10); booking.addView(bookingResult,lp);
        submit.setOnClickListener(v -> createBooking());

        LinearLayout tracking = card(page, "🔎  Track your parcel", "Use the tracking number created for a demo booking.");
        trackInput = field(tracking, "Tracking number", "e.g. COP-ABC123");
        Button track = button("Track parcel"); tracking.addView(track, params(-1,-2));
        trackingResult = text("", 14, dark, false); lp=params(-1,-2);lp.topMargin=dp(10);tracking.addView(trackingResult,lp);
        track.setOnClickListener(v -> trackBooking());

        TextView warning = text("Important: this first version stores demo bookings only on this phone. Orders are NOT sent to an admin, and live GPS tracking, online accounts and online database are not connected yet. Do not use real customer details until secure online storage is added.", 13, Color.rgb(113,63,18), false);
        warning.setPadding(dp(13),dp(13),dp(13),dp(13)); warning.setBackground(round(Color.rgb(255,251,235),12));
        lp=params(-1,-2);lp.topMargin=dp(14);page.addView(warning,lp);
        TextView footer=text("© Carry-On Pick-Up • Abhaynagar, Jashore",12,muted,false); footer.setGravity(Gravity.CENTER);lp=params(-1,-2);lp.topMargin=dp(20);page.addView(footer,lp);
        setContentView(scroll);
    }

    private LinearLayout card(LinearLayout parent, String heading, String sub) {
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(15),dp(16),dp(15),dp(16));box.setBackground(round(Color.WHITE,18));
        LinearLayout.LayoutParams lp=params(-1,-2);lp.topMargin=dp(14);parent.addView(box,lp);
        box.addView(text(heading,20,dark,true)); TextView desc=text(sub,13,muted,false);lp=params(-1,-2);lp.topMargin=dp(5);box.addView(desc,lp);return box;
    }
    private void addStat(LinearLayout row,String title,String subtitle){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(9),dp(12),dp(7),dp(12));box.setBackground(round(Color.WHITE,13));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.setMargins(dp(3),0,dp(3),0);row.addView(box,lp);box.addView(text(title,13,dark,true));box.addView(text(subtitle,10,muted,false));}
    private EditText field(LinearLayout parent,String label,String hint){return field(parent,label,hint,false);}
    private EditText field(LinearLayout parent,String label,String hint,boolean multiline){TextView l=text(label,13,dark,true);LinearLayout.LayoutParams lp=params(-1,-2);lp.topMargin=dp(12);parent.addView(l,lp);EditText e=new EditText(this);e.setSingleLine(!multiline);e.setTextSize(15);e.setHint(hint);e.setTextColor(dark);e.setHintTextColor(muted);e.setPadding(dp(11),dp(8),dp(11),dp(8));e.setBackground(round(Color.rgb(250,253,252),10));if(multiline){e.setMinLines(2);e.setGravity(Gravity.TOP);}lp=params(-1,-2);lp.topMargin=dp(5);parent.addView(e,lp);return e;}
    private Spinner spinner(LinearLayout parent,String label,String[] options){TextView l=text(label,13,dark,true);LinearLayout.LayoutParams lp=params(-1,-2);lp.topMargin=dp(12);parent.addView(l,lp);Spinner s=new Spinner(this);ArrayAdapter<String>a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,options);a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);s.setAdapter(a);lp=params(-1,dp(48));lp.topMargin=dp(4);parent.addView(s,lp);return s;}
    private Button button(String label){Button b=new Button(this);b.setText(label);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setTextSize(15);b.setTypeface(null,Typeface.BOLD);b.setBackground(round(green,12));LinearLayout.LayoutParams lp=params(-1,dp(52));lp.topMargin=dp(14);b.setLayoutParams(lp);return b;}
    private TextView text(String value,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    private GradientDrawable round(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private LinearLayout.LayoutParams params(int w,int h){return new LinearLayout.LayoutParams(w,h);}
    private int dp(int value){return (int)(value*getResources().getDisplayMetrics().density+0.5f);}
    private String value(EditText e){return e.getText().toString().trim();}
    private void createBooking(){
        if(value(sender).isEmpty()||value(phone).isEmpty()||value(pickup).isEmpty()||value(receiver).isEmpty()||value(receiverPhone).isEmpty()||value(delivery).isEmpty()||parcelType.getSelectedItemPosition()==0){Toast.makeText(this,"Please fill all required fields.",Toast.LENGTH_LONG).show();return;}
        String id="COP-"+UUID.randomUUID().toString().replace("-","").substring(0,6).toUpperCase(Locale.ROOT);
        try{JSONArray list=new JSONArray(prefs.getString("bookings","[]"));JSONObject b=new JSONObject();b.put("id",id);b.put("created",new SimpleDateFormat("dd MMM yyyy, hh:mm a",Locale.getDefault()).format(new Date()));b.put("status","Demo booking saved on this phone");b.put("sender",value(sender));b.put("phone",value(phone));b.put("pickup",value(pickup));b.put("receiver",value(receiver));b.put("receiverPhone",value(receiverPhone));b.put("delivery",value(delivery));b.put("type",parcelType.getSelectedItem().toString());b.put("weight",weight.getSelectedItem().toString());b.put("instructions",value(instructions));list.put(b);prefs.edit().putString("bookings",list.toString()).apply();bookingResult.setText("Demo booking saved on this phone. Tracking number: "+id+". Save this number. This request has NOT been sent to a courier/admin.");trackInput.setText(id);Toast.makeText(this,"Demo booking created",Toast.LENGTH_SHORT).show();}catch(Exception ex){Toast.makeText(this,"Could not save booking.",Toast.LENGTH_LONG).show();}
    }
    private void trackBooking(){String id=value(trackInput).toUpperCase(Locale.ROOT);try{JSONArray list=new JSONArray(prefs.getString("bookings","[]"));for(int i=0;i<list.length();i++){JSONObject b=list.getJSONObject(i);if(id.equalsIgnoreCase(b.getString("id"))){trackingResult.setText("Tracking number: "+id+"\nStatus: "+b.getString("status")+"\nParcel type: "+b.getString("type")+"\nCreated: "+b.getString("created"));return;}}trackingResult.setText("No matching demo booking found on this phone. Online tracking will be added when a secure backend is connected.");}catch(Exception ex){trackingResult.setText("Unable to look up this demo booking.");}}
}
